#version 330
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
out vec4 itemColor;
out vec2 texCoord;
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position,1.0);
    itemColor = Color * ColorModulator;
    texCoord = UV0;
}
