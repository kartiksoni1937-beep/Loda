package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.shard;

public class PoolScheduler {
}
