package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.cluster;

import net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex.SortableData;

public interface CoreSerializer extends SortableData {
   void a(LinkerFactory var1);
}
