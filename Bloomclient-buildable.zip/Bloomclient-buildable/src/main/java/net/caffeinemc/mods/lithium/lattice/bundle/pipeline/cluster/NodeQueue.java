package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.cluster;

import net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex.SortableData;

public interface NodeQueue extends SortableData {
   void a(ViewDelegate var1);
}
