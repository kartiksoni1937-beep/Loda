package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex;

public interface SortableData {
   byte[][] c = new byte[3][];
   int[] d = new int[]{0, 0};
}
