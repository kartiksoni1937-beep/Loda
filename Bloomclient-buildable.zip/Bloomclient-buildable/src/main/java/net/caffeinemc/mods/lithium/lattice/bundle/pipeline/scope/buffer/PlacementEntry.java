package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.scope.buffer;

public final class PlacementEntry extends BlockCalculator {

   public PlacementEntry(String var1, double var2, double var4, double var6, double var8) {
      super(var1, var2, var4, var6, var8);
   }
}
