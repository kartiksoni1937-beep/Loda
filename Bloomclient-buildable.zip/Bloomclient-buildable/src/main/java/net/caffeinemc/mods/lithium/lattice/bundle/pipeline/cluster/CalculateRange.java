package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.cluster;

import net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex.SortableData;

public interface CalculateRange extends SortableData {
   void a(BufferEncoder var1);
}
