package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.cluster;

import net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex.SortableData;

public interface InitNotifier extends SortableData {
   void a();
}
