package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.shard;

public class SyncController {
   public static int b = 88;
   public static int c = 166;
   public static int d = 255;
   public static int e = 20;
   public static int f = 25;
   public static int g = 40;
   public static boolean m = false;
   public static float n = 1.0F;
   public static boolean o = false;
   public static boolean q = true;
   public static boolean r = true;
   public static boolean s = false;
   public static boolean t = true;
   public static boolean u = false;
   public static boolean v = true;
   public static boolean w = true;
   public static boolean x = false;
   public static boolean y = true;
   public static int a = 2;
   public static int h = 1;
   public static int i = 62;
   public static int j = 70;
   public static boolean k = true;
   public static int l = 1;
   public static int p = 0;
   public static boolean z = true;
   public static boolean aa = true;
   public static boolean ab = false;
   public static boolean ac = false;
   public static int ad = 0;
   public static boolean ae = true;
   public static int af = 100;
   public static int ag = 1;
   public static int ah = 0;
   public static int ai = 78;

   public static float vol() {

      int var0 = af;
      return (float)(var0 <= 0 ? 0 : (var0 >= (169038783 ^ 169038633) ? -839289676 ^ -839289822 : var0)) / 100.0F;
   }
}
