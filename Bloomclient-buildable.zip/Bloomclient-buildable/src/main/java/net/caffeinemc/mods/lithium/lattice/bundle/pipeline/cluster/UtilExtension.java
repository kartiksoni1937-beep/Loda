package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.cluster;

import net.caffeinemc.mods.lithium.lattice.bundle.pipeline.vertex.SortableData;
import net.minecraft.client.gui.DrawContext;

public interface UtilExtension extends SortableData {
   void a(DrawContext var1);
}
