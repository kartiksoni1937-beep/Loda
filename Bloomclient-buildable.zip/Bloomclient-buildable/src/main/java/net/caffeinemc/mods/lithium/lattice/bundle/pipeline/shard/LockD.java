package net.caffeinemc.mods.lithium.lattice.bundle.pipeline.shard;

public final class LockD {
   public static volatile boolean a = false;
   public static volatile long b = 0L;
   public static volatile Runnable c = null;
   public static volatile Runnable d = null;
   public static volatile Runnable e = null;
   public static volatile long f = 0L;
   public static volatile boolean g = false;
   public static volatile boolean h = false;

   private LockD() {
   }
}
